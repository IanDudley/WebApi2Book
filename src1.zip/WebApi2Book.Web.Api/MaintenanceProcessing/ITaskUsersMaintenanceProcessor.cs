﻿using System.Collections.Generic;
using WebApi2Book.Web.Api.Models;

namespace WebApi2Book.Web.Api.MaintenanceProcessing
{
    public interface ITaskUsersMaintenanceProcessor
    {
        Task ReplaceTaskUsers(long taskId, IEnumerable<long> UserIds);
        Task DeleteTaskUsers(long taskId);
        Task AddTaskUser(long taskId, long UserId);
        Task DeleteTaskUser(long taskId, long userId);
    }
}
