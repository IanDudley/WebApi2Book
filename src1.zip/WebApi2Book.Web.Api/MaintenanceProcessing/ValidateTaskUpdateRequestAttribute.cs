﻿using System;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using log4net;
using log4net.Core;
using Microsoft.IdentityModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WebApi2Book.Common.Logging;
using WebApi2Book.Web.Api.Models;
using WebApi2Book.Web.Common;

namespace WebApi2Book.Web.Api.MaintenanceProcessing
{
    public class ValidateTaskUpdateRequestAttribute : ActionFilterAttribute
    {
        private readonly ILog _log;


        public ValidateTaskUpdateRequestAttribute() : this(WebContainerManager.Get<ILogManager>())
        {
        }

        public ValidateTaskUpdateRequestAttribute(ILogManager logManager)
        {
            _log = logManager.GetLog(typeof (ValidateTaskUpdateRequestAttribute));
        }

        public override bool AllowMultiple
        {
            get { return false; }
        }

        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            var taskId = (long) actionContext.ActionArguments[ActionParameterNames.TaskId];
            var taskFragment = (JObject) actionContext.ActionArguments[ActionParameterNames.TaskFragment];
            _log.DebugFormat("{0} = {1}", ActionParameterNames.TaskFragment, taskFragment);
            
            if (taskFragment == null)
            {
                const string errorMessage = "Malformed or null request.";
                _log.Debug(errorMessage);
                actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest,
                    errorMessage);
                return;
            }

            try
            {
                var task = taskFragment.ToObject<Task>();
                if (task.TaskId.HasValue && task.TaskId != taskId)
                {
                    const string errorMessage = "Task ids do not match.";
                    _log.Debug(errorMessage);
                    actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest,
                    errorMessage);
                }
            }
            catch (JsonException ex)
            {
                _log.Debug(ex.Message);
                actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        public static class ActionParameterNames
        {
            public const string TaskFragment = "updatedTask";
            public const string TaskId = "id";
        }
    }
}