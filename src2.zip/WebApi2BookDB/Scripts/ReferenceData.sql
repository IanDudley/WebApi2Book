﻿if not exists(select * from dbo.Status where Name = 'Not Started')
	insert into dbo.Status (Name, Ordinal) Values ('Not Started', 0);
if not exists(select * from dbo.Status where Name = 'In Progress')
	insert into dbo.Status (Name, Ordinal) Values ('In Progress', 1);
if not exists(select * from dbo.Status where Name = 'Completed')
	insert into dbo.Status (Name, Ordinal) Values ('Completed', 2);